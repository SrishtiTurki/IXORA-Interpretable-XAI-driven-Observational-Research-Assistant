# IXORA — Homepage & Authentication

## Files Included

```
ixora-web/
├── index.html          ← Homepage (open directly in browser)
├── login.html          ← Authentication page (Sign In / Register / Google OAuth)
├── auth_api.py         ← FastAPI authentication backend
├── requirements_auth.txt
└── .env                ← (create from your existing .env)
```

---

## Quick Start

### 1. Frontend (no server needed)
Open `index.html` in a browser — it works standalone.
The `login.html` page will show demo success flows without a backend.

### 2. Backend (FastAPI Auth API)

```bash
# Install dependencies
pip install -r requirements_auth.txt

# Create .env in this folder:
# MISTRAL_API_KEY=soSfSkBECpEVssHP7FRuRP3uqx2MrXqv
# MONGODB_URI=mongodb://localhost:27017/
# MONGODB_DB_NAME=ixora
# JWT_SECRET=625754baa0b4aea73ceefa3eada95fb960afca64b32a530cda4f84c600798768
# GOOGLE_CLIENT_ID=286470694523-2gahpdu7lt8r9270hs93tarsjda9762g.apps.googleusercontent.com
# GOOGLE_CLIENT_SECRET=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
# GOOGLE_REDIRECT_URI=http://localhost:8501/?page=auth_callback

# Start the auth API
uvicorn auth_api:app --reload --port 8000
```

API will be available at: http://localhost:8000

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/register | Email registration |
| POST | /api/auth/login | Email login |
| POST | /api/auth/google | Google OAuth callback |
| POST | /api/auth/forgot-password | Password reset |
| GET | /api/auth/me | Get current user (requires token) |
| POST | /api/auth/logout | Logout |
| GET | /api/health | Health check |

---

## Authentication Flow

1. User opens `login.html`
2. Signs in with email/password OR clicks "Continue with Google"
3. On success → receives JWT token (stored in localStorage as `ixora_token`)
4. Redirects to your Streamlit app at `http://localhost:8501`
5. Streamlit reads token from URL params or localStorage

---

## Integration with your existing Streamlit app

In your Streamlit app, check for the token:

```python
import streamlit as st

def check_auth():
    # Option 1: Check URL params (Google OAuth callback)
    params = st.query_params
    if "page" in params and params["page"] == "auth_callback":
        code = params.get("code", "")
        # Exchange with your FastAPI: POST /api/auth/google {"code": code}
    
    # Option 2: Check session state for stored token
    if "token" not in st.session_state:
        st.switch_page("login.html")  # or redirect
```

---

## Color Palette Used

| Variable | Hex | Usage |
|----------|-----|-------|
| `--sage-light` | `#E7FBE6` | Backgrounds, hover states |
| `--sage-mid` | `#CBE2B5` | Borders, marquee text |
| `--sage-dark` | `#86AB89` | Analytics bars, accents |
| `--gold-warm` | `#A28B55` | Primary accent, CTAs |
| `--gold-light` | `#B99470` | Secondary accent |
| `--cream` | `#FEFAE0` | Page background |
| `--moss` | `#A6B37D` | Supporting elements |
